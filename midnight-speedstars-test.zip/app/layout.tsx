import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import type React from "react"
import { SplashScreen } from "@/components/splash-screen"
import { Logo } from "@/components/logo"
import { CustomCursor } from "@/components/custom-cursor"
import { Instagram } from "lucide-react"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Midnight Speedstars - Performance Auto Parts",
  description: "Premium automotive performance parts and accessories",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body className={`${inter.className} bg-dark-900 text-gray-100`}>
        <SplashScreen />
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50">
          <Logo />
        </div>
        {children}
        <footer className="w-full py-6 px-4 bg-dark-600 text-gray-400">
          <div className="container mx-auto flex justify-between items-center">
            <p>&copy; 2023 Midnight Speedstars. All rights reserved.</p>
            <a
              href="https://www.instagram.com/midnightspeedstars/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-full hover:bg-gradient-to-tr from-purple-600 via-pink-600 to-yellow-500 transition-colors duration-300"
            >
              <Instagram className="w-6 h-6 text-gray-400 hover:text-white transition-colors duration-300" />
            </a>
          </div>
        </footer>
        <CustomCursor />
      </body>
    </html>
  )
}

