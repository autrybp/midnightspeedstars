import { ProductCard } from "@/components/product-card"
import { AutoSliderBanner } from "@/components/auto-slider-banner"

export default function Home() {
  const products = [
    {
      id: 1,
      name: "MS Performance Exhaust",
      price: 899.99,
      image1: "https://images.unsplash.com/photo-1621252179027-94459d278660?auto=format&fit=crop&q=80&w=1000",
      image2: "https://images.unsplash.com/photo-1626668893632-6f3a4466d22f?auto=format&fit=crop&q=80&w=1000",
    },
    {
      id: 2,
      name: "MS Coilover Kit",
      price: 1299.99,
      image1: "https://images.unsplash.com/photo-1611821064430-0d40291d0f0b?auto=format&fit=crop&q=80&w=1000",
      image2: "https://images.unsplash.com/photo-1600705722738-d39380209f19?auto=format&fit=crop&q=80&w=1000",
    },
    {
      id: 3,
      name: "MS Carbon Fiber Wing",
      price: 799.99,
      image1: "https://images.unsplash.com/photo-1606016159991-dfe4f2746ad5?auto=format&fit=crop&q=80&w=1000",
      image2: "https://images.unsplash.com/photo-1610986603166-f78428624e76?auto=format&fit=crop&q=80&w=1000",
    },
    {
      id: 4,
      name: "MS Limited Edition Wheels",
      price: 2499.99,
      image1: "https://images.unsplash.com/photo-1611921059723-c2fe6a61c526?auto=format&fit=crop&q=80&w=1000",
      image2: "https://images.unsplash.com/photo-1611921057751-108f47ef2476?auto=format&fit=crop&q=80&w=1000",
    },
  ]

  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      <AutoSliderBanner />
      <section id="product-section" className="w-full py-12 md:py-24 bg-dark-900">
        <div className="container mx-auto px-4">
          <h2 className="mb-8 text-3xl font-bold text-center text-gray-100">Featured Products</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>
        </div>
      </section>
    </main>
  )
}

