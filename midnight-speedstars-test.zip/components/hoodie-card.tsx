import Image from "next/image"

interface Product {
  id: number
  name: string
  price: number
  image1: string
  image2: string
}

export function HoodieCard({ id, name, price, image1, image2 }: Product) {
  return (
    <div className="bg-dark-800 rounded-lg shadow-lg p-6">
      <div className="relative h-64">
        <Image src={image1 || "/placeholder.svg"} alt={name} fill className="object-cover rounded-lg" priority />
      </div>
      <h3 className="mt-4 text-xl font-bold text-gray-100">{name}</h3>
      <p className="mt-2 text-gray-300">${price.toFixed(2)}</p>
    </div>
  )
}

