import Image from "next/image"

export function Logo() {
  return (
    <div className="relative w-24 h-24">
      <div className="absolute inset-0 bg-red-500 opacity-50 blur-xl rounded-full"></div>
      <Image
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-THZJZu3vV0vBnPJ83QygrrkWmUSTNb.png"
        alt="Midnight Speedstars"
        fill
        className="object-contain relative z-10"
        priority
      />
    </div>
  )
}

