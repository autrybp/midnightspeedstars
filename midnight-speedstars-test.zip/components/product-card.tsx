"use client"

import Image from "next/image"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ShoppingCart } from "lucide-react"

interface Product {
  id: number
  name: string
  price: number
  image1: string
  image2: string
}

export function ProductCard({ id, name, price, image1, image2 }: Product) {
  const [isHovered, setIsHovered] = useState(false)

  const handleAddToCart = () => {
    // TODO: Implement add to cart functionality
    console.log(`Added ${name} to cart`)
  }

  return (
    <div
      className="bg-dark-800 rounded-lg shadow-lg overflow-hidden"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative h-64">
        <Image
          src={isHovered ? image2 : image1}
          alt={name}
          fill
          className="object-cover transition-opacity duration-300"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
          priority
        />
      </div>
      <div className="p-4">
        <h3 className="text-xl font-bold text-gray-100">{name}</h3>
        <p className="mt-2 text-gray-300">${price.toFixed(2)}</p>
        <Button onClick={handleAddToCart} className="mt-4 w-full" variant="outline">
          <ShoppingCart className="mr-2 h-4 w-4" /> Add to Cart
        </Button>
      </div>
    </div>
  )
}

